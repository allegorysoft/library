﻿namespace MyCompanyName.MyProjectName;

public static class MyProjectNameErrorCodes
{
    //Add your business exception error codes here...
}
