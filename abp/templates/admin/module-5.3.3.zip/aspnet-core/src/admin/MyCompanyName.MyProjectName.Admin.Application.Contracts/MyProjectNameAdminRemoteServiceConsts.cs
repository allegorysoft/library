﻿namespace MyCompanyName.MyProjectName.Admin;

public class MyProjectNameAdminRemoteServiceConsts
{
    public const string RemoteServiceName = "MyProjectNameAdmin";

    public const string ModuleName = "myProjectName-admin";
}
