﻿namespace MyCompanyName.MyProjectName.Admin.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
