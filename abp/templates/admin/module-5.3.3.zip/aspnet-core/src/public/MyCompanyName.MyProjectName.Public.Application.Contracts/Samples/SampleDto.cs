﻿namespace MyCompanyName.MyProjectName.Public.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
