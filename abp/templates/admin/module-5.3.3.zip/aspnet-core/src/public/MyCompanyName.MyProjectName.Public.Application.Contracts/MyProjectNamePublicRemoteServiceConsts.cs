﻿namespace MyCompanyName.MyProjectName.Public;

public class MyProjectNamePublicRemoteServiceConsts
{
    public const string RemoteServiceName = "MyProjectNamePublic";

    public const string ModuleName = "myProjectName-public";
}
