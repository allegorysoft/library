﻿namespace MyCompanyName.MyProjectName.Common;

public class MyProjectNameCommonRemoteServiceConsts
{
    public const string RemoteServiceName = "MyProjectNameCommon";

    public const string ModuleName = "myProjectName-common";
}
