﻿namespace MyCompanyName.MyProjectName.Common.Samples;

public class SampleDto
{
    public int Value { get; set; }
}
