﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.Common;

public class MyProjectNameCommonApplicationAutoMapperProfile : Profile
{
    public MyProjectNameCommonApplicationAutoMapperProfile()
    {
        /* You can configure your AutoMapper mapping configuration here.
         * Alternatively, you can split your mapping configurations
         * into multiple profile classes for a better organization. */
    }
}
