using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace MyCompanyName.MyProjectName.Pages;

public class IndexModel : AbpPageModel
{
    public void OnGet()
    {
    }
}
