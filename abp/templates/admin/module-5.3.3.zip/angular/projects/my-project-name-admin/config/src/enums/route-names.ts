export const enum eMyProjectNameAdminRouteNames {
  MyProjectNameAdmin = 'MyProjectNameAdmin',
}
