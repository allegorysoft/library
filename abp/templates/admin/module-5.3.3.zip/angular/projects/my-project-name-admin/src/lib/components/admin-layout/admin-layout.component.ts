import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-admin-layout',
  templateUrl: './admin-layout.component.html'
})
export class AdminLayoutComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
