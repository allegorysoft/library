/*
 * Public API Surface of my-project-name-admin
 */

export * from './lib/components/admin-layout/admin-layout.component';
export * from './lib/components/admin-layout/admin-layout.module';
export * from './lib/components/my-project-name-admin.component';
export * from './lib/services/my-project-name-admin.service';
export * from './lib/my-project-name-admin.module';
