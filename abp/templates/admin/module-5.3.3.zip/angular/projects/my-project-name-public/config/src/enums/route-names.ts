export const enum eMyProjectNamePublicRouteNames {
  MyProjectNamePublic = 'MyProjectNamePublic',
}
