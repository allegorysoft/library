import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-public-layout',
  templateUrl: './public-layout.component.html'
})
export class PublicLayoutComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
